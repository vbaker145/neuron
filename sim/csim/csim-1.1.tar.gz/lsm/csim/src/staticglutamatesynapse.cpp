/*! \file staticglutamatesynapse.cpp
**  \brief Implementation of StaticGlutamateSynapse
*/

#include "staticglutamatesynapse.h"
