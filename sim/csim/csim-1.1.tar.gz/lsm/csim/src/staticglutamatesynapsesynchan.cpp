/*! \file staticglutamatesynapsesynchan.cpp
**  \brief Implementation of StaticGlutamateSynapseSynchan
*/

#include "staticglutamatesynapsesynchan.h"
