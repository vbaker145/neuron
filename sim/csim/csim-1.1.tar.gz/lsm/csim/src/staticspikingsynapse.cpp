/*! \file staticspikingsynapse.cpp
**  \brief Implementation of StaticSpikingSynapse
*/

// empty bcs StaticSpikingsynapse is just the Matlab visible alias of SpikingSynapse

#include "staticspikingsynapse.h"
